import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-server-element',
  templateUrl: './server-element.component.html',
  styleUrls: ['./server-element.component.css'],
  //encapsulation: ViewEncapsulation.None
  //We use this property to turn off the view encapsulation so that style can be applied globally.
})
export class ServerElementComponent implements OnInit {
 //We are using @Input so that element property is accessible outside this component and we can bind it and
 //has alias name srvElement and we can access with this name only
  @Input('srvElement') element: {type:string,name:string,content:string};
  constructor() { }

  ngOnInit() {
  }

}
