import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router: Router, private route: ActivatedRoute ) { }

  ngOnInit() {
  }
  
  onLoadServer(){
    this.router.navigate(['/servers']);
    // this.router.navigate(['/servers'],{ relativeTo: this.route});
    //this extra property tells which route it is relative to as navigate doesn't store this information different from routerLink
  }
}
