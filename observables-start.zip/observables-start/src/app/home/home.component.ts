import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    const myObservable = Observable.create((observer: Observer<string>)=>{
      setTimeout(()=>{
        observer.next('first package');
      },2000);
      setTimeout(()=>{
        observer.next('second package');
      },4000);
      // setTimeout(()=>{
      //   observer.error('error');
      // },5000);
      setTimeout(()=>{
        observer.complete();
      },6000);
  });
  myObservable.subscribe(
    (data: string)=>{console.log(data);},
    (error: string)=>{console.log(error);},
    ()=>{console.log('completed');},
  );

  //Observer : our code, subscribe function here we have 3 ways to handle data packages
//handle normal data, error or the completion of the observable




  }

}
